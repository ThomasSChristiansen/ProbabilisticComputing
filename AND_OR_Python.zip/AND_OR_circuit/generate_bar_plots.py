import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

def clean_and_output(value):
    if isinstance(value, str):
        value = value.strip()
        # Extract only the last 5 bits (rightmost three digits)
        value = value[-5:] if len(value) > 5 else value  
        if value in [f"{i:05b}" for i in range(32)]:  # Ensure it's a valid 5-bit binary number
            return value
    elif isinstance(value, int):
        return f"{value:05b}"[-5:]  # Convert integer to 5-bit binary and keep last 5 bits
    return None  # Ignore invalid cases

def generate_bar_plots(file_path,savefig=False, save_csv=True):
    
    # Define the mapping for descriptive labels
    label_mapping = {
        ( 0.0,  0.0, -8.0, -2.0, -4.0): 'Floating State',
    }

    # Load the data
    data = pd.read_csv(file_path, low_memory=False)
    data.columns = data.columns.str.strip()  # Remove whitespace from column names

    # Ensure h1, h2, h3 are floats
    for col in ['h1', 'h2', 'h3', 'h4', 'h5']:
        data[col] = pd.to_numeric(data[col], errors='coerce').fillna(0).astype(float)

    # **Apply the label mapping to create a descriptive label column**
    data['label'] = data.apply(
        lambda row: label_mapping.get((row['h1'], row['h2'], row['h3'], row['h4'], row['h5']), 'Unknown'), axis=1
    )

    # Filter out rows without a known label
    labeled_data = data[data['label'] != 'Unknown']

    # Apply the corrected function for 5-bit output conversion
    labeled_data['output_cleaned'] = labeled_data['output'].apply(clean_and_output)
    cleaned_data = labeled_data.dropna(subset=['output_cleaned'])

    # Group data correctly by (label, output)
    grouped = cleaned_data.groupby(['label', 'output_cleaned']).size().unstack(fill_value=0)

    # Define all possible cases {00000, ..., 11111}
    possible_cases = [f"{i:05b}" for i in range(32)]
    all_results = []  # To store the results for all labels

    # Plot each unique label
    for label, row in grouped.iterrows():
        # Align counts with all possible cases, filling missing ones with 0
        aligned_counts = [row.get(case, 0) for case in possible_cases]

        # Normalize counts to probability distribution
        total = sum(aligned_counts)
        normalized_counts = [c / total if total > 0 else 0 for c in aligned_counts]

        # Append results to the list
        all_results.append({
            'label': label,
            'possible_cases': possible_cases,
            'normalized_counts': normalized_counts
        })
        
        # Plot the distribution
        plt.figure(figsize=(8, 6))
        plt.bar(possible_cases, normalized_counts, tick_label=possible_cases)
        plt.title(f"{label}: Bar Plot of Output Cases")
        plt.ylabel("Probability")
        plt.xticks(rotation=45)
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        if savefig:
            file_name = f"AND_OR_Behav_{label.replace(' ', '_').replace('=', '_')}.png"
            plt.savefig(os.path.join("Plots", file_name), dpi=300)
        plt.show()

    # Save all results to CSV
    if save_csv:
        results_df = pd.DataFrame([
            {
                'label': result['label'],
                'case': case,
                'normalized_count_FPGA': normalized_count
            }
            for result in all_results
            for case, normalized_count in zip(result['possible_cases'], result['normalized_counts'])
        ])
        results_df.to_csv("AND_OR_Behav.csv", index=False)
        print("Labeled results saved to 'AND_OR_Behav.csv'")